/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import com.sun.istack.logging.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.UserAccount;
import uts.isd.model.ShipmentDetails;
import uts.isd.model.dao.Database;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author Jeongseongwoo
 */
@WebServlet("/ShipmentDetailsServlet")
public class ShipmentDetailsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Database manager = new Database();
        
        UserAccount userAccount = (UserAccount) session.getAttribute("userAccount");
        int userID = userAccount.getUserAccountID();


        ShipmentDetails shipmentDetails = manager.findShipmentDetailsWithUserID(userID);
        
        session.setAttribute("shipmentDetails", shipmentDetails);
        request.getRequestDispatcher("shipmentdetails.jsp").include(request, response);

    }
}
