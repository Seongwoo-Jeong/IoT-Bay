/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.ShipmentDetails;
import uts.isd.model.dao.Database;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import uts.isd.model.UserAccount;

/**
 *
 * @author Jeongseongwoo
 */
@WebServlet("/AddShipmentDetailsServlet")
public class AddShipmentDetailsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        ShipmentValidator validator = new ShipmentValidator();
        Database manager = new Database();
        
        UserAccount userAccount = (UserAccount) session.getAttribute("userAccount");
        int userAccountID = userAccount.getUserAccountID();
        
        String streetNameNumber = request.getParameter("streetNameNumber");
        String suburb = request.getParameter("suburb");
        String state = request.getParameter("state");
        int postcode = Integer.parseInt(request.getParameter("postcode"));
        
        session.setAttribute("addSuccess", null);
        session.setAttribute("ressErr", null);
        session.setAttribute("postcodeErr", null);

        if (!validator.validateShipmentNameNumber(streetNameNumber)) {
            session.setAttribute("ressErr", "Format error! sequence is wrong");
            request.getRequestDispatcher("addShipmentDetails.jsp").include(request, response);
        } else if (!validator.validatePostcode(postcode)) {
            session.setAttribute("postcodeErr", "Invalid postcode, please try again.");
            request.getRequestDispatcher("addShipmentDetails.jsp").include(request, response);
        } else {
            ShipmentDetails shipmentDetails = new ShipmentDetails(streetNameNumber, suburb, postcode, state, userAccountID);
            manager.addShipmentDetails(shipmentDetails, 16);
            session.setAttribute("addSuccess", "Shipment detail has been added to your account.");
            session.setAttribute("userAccount", null);
            session.setAttribute("shipmentDetails",shipmentDetails);
            request.getRequestDispatcher("shipmentdetails.jsp").include(request, response);

        }
    }
}
