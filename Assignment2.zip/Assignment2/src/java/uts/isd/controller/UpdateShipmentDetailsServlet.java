/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import uts.isd.model.ShipmentDetails;
import uts.isd.model.dao.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.UserAccount;

/**
 *
 * @author Jeongseongwoo
 */
@WebServlet("/UpdateShipmentDetailsServlet")
public class UpdateShipmentDetailsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Database manager = new Database();
        ShipmentValidator validator = new ShipmentValidator();

        ShipmentDetails shipmentDetails = null;
        String streetNameNumber = request.getParameter("streetAddress");
        String suburb = request.getParameter("suburb");
        int postcode = Integer.parseInt(request.getParameter("postcode"));
        String state = request.getParameter("state");
        
        UserAccount userAccount = (UserAccount) session.getAttribute("userAccount");
        int userAccountID = userAccount.getUserAccountID();
        ShipmentDetails previousShipmentDetails = manager.findShipmentDetailsWithUserID(userAccountID);
        int shipmentDetailsID = previousShipmentDetails.getShipmentDetailsID();
        
        session.setAttribute("streetNameNumberErr", null);
        session.setAttribute("postcodeErr", null);
        session.setAttribute("shipmentD", null);

        shipmentDetails = new ShipmentDetails(streetNameNumber, suburb, postcode, state, userAccountID);
        
        if (!validator.validateShipmentNameNumber(streetNameNumber)) {
            session.setAttribute("streetNameNumberErr", "Invalid Street Name Number");
            request.getRequestDispatcher("EditShipmentDetails.jsp").include(request, response);

        } else if (!validator.validatePostcode(postcode)) {
            session.setAttribute("postcodeErr", "Invalid postcode");
            request.getRequestDispatcher("EditShipmentDetails.jsp").include(request, response);
        } else {
            manager.updateShipmentDetails(new ShipmentDetails(shipmentDetailsID, streetNameNumber, suburb, postcode, state, userAccountID));
            session.setAttribute("shipmentD", shipmentDetails);
            request.getRequestDispatcher("shipmentdetails.jsp").include(request, response);
        }
        

    }
}
