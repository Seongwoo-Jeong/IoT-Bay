/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import uts.isd.model.Shipment;
import com.sun.istack.logging.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.UserAccount;
import uts.isd.model.ShipmentDetails;
import uts.isd.model.dao.Database;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author Jeongseongwoo
 */
@WebServlet("/ViewShipmentServlet")
public class ViewShipmentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Database manager = new Database();

        ArrayList<Shipment> shipments = new ArrayList<Shipment>();

        UserAccount userAccount = (UserAccount) session.getAttribute("userAccount");
        int userAccountID = userAccount.getUserAccountID();

        session.setAttribute("shipments", null);
        session.setAttribute("shipmentErr", null);

        shipments = manager.getAllShipments(userAccountID);

        if (shipments != null) {
            session.setAttribute("shipments", shipments);
        } else {
            String shipmentErr = "You don't have any exisiting or previous Shipments!";
            session.setAttribute("shipmentErr", shipmentErr);
        }
        request.getRequestDispatcher("viewshipment.jsp").include(request, response);

    }
}
